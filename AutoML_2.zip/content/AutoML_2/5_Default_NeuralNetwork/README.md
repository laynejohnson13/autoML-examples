# Summary of 5_Default_NeuralNetwork

[<< Go back](../README.md)


## Neural Network
- **n_jobs**: -1
- **dense_1_size**: 32
- **dense_2_size**: 16
- **learning_rate**: 0.05
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

3.6 seconds

### Metric details
|           |    Extreme |      Major |      Minor |   Moderate |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.734694 |   0.55527  |   0.832749 |   0.588889 |   0.711434 |    0.6779   |       0.709097 |   0.77771 |
| recall    |   0.327273 |   0.662577 |   0.896725 |   0.501182 |   0.711434 |    0.596939 |       0.711434 |   0.77771 |
| f1-score  |   0.45283  |   0.604196 |   0.863554 |   0.541507 |   0.711434 |    0.615522 |       0.702661 |   0.77771 |
| support   | 110        | 326        | 794        | 423        |   0.711434 | 1653        |    1653        |   0.77771 |


## Confusion matrix
|                     |   Predicted as Extreme |   Predicted as Major |   Predicted as Minor |   Predicted as Moderate |
|:--------------------|-----------------------:|---------------------:|---------------------:|------------------------:|
| Labeled as Extreme  |                     36 |                   70 |                    2 |                       2 |
| Labeled as Major    |                     12 |                  216 |                   22 |                      76 |
| Labeled as Minor    |                      0 |                   12 |                  712 |                      70 |
| Labeled as Moderate |                      1 |                   91 |                  119 |                     212 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
