# Summary of 3_Linear

[<< Go back](../README.md)


## Logistic Regression (Linear)
- **n_jobs**: -1
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

14.2 seconds

### Metric details
|           |    Extreme |      Major |      Minor |   Moderate |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.673684 |   0.60745  |   0.844869 |   0.595687 |   0.728978 |    0.680423 |       0.722889 |  0.638166 |
| recall    |   0.581818 |   0.650307 |   0.891688 |   0.522459 |   0.728978 |    0.661568 |       0.728978 |  0.638166 |
| f1-score  |   0.62439  |   0.628148 |   0.867647 |   0.556675 |   0.728978 |    0.669215 |       0.724649 |  0.638166 |
| support   | 110        | 326        | 794        | 423        |   0.728978 | 1653        |    1653        |  0.638166 |


## Confusion matrix
|                     |   Predicted as Extreme |   Predicted as Major |   Predicted as Minor |   Predicted as Moderate |
|:--------------------|-----------------------:|---------------------:|---------------------:|------------------------:|
| Labeled as Extreme  |                     64 |                   44 |                    2 |                       0 |
| Labeled as Major    |                     29 |                  212 |                   12 |                      73 |
| Labeled as Minor    |                      0 |                    9 |                  708 |                      77 |
| Labeled as Moderate |                      2 |                   84 |                  116 |                     221 |

## Learning curves
![Learning curves](learning_curves.png)

## Coefficients

### Coefficients learner #1
|                                     |     Extreme |        Major |        Minor |     Moderate |
|:------------------------------------|------------:|-------------:|-------------:|-------------:|
| intercept                           | -5.0521     |  0.506376    |  2.36178     |  2.18395     |
| Health Service Area                 | -0.0502724  |  0.0203977   |  0.0345624   | -0.00468772  |
| Hospital County                     | -0.0568071  |  0.0189791   |  0.030784    |  0.00704407  |
| Operating Certificate Number        | -0.150132   | -0.0117226   |  0.00796816  |  0.153886    |
| Facility Id                         |  0.106408   |  0.0432713   | -0.034503    | -0.115177    |
| Facility Name                       |  0.0554123  | -0.0323695   |  0.0252901   | -0.0483329   |
| Age Group                           |  1.13456    |  0.814884    | -1.66031     | -0.289134    |
| Zip Code - 3 digits                 |  0.0293395  |  0.0251056   | -0.0542781   | -0.000166934 |
| Gender                              |  0.069181   |  0.0427294   | -0.111787    | -0.00012304  |
| Race                                |  0.082933   |  0.0176964   | -0.0422063   | -0.058423    |
| Ethnicity                           |  0.126381   | -0.0679774   | -0.00918822  | -0.0492153   |
| Length of Stay                      |  0.0154437  |  0.0924797   | -0.165267    |  0.0573435   |
| Type of Admission                   |  0.0509253  | -0.00405211  |  0.000140646 | -0.0470138   |
| Patient Disposition                 | -0.150892   |  0.155317    | -0.115629    |  0.111204    |
| CCS Diagnosis Code                  | -0.679156   | -0.137796    |  0.634359    |  0.182593    |
| CCS Diagnosis Description           | -0.0318515  |  0.0356513   |  0.0630427   | -0.0668425   |
| CCS Procedure Code                  |  0.200297   | -0.0680365   | -0.0166972   | -0.115563    |
| CCS Procedure Description           |  0.0740494  | -0.0247659   | -0.0580604   |  0.00877696  |
| APR DRG Code                        |  0.142933   |  0.106711    | -0.176072    | -0.0735718   |
| APR DRG Description                 |  0.00892031 | -0.000620911 | -0.0306821   |  0.0223827   |
| APR MDC Code                        | -0.0648821  | -0.0814302   |  0.0919584   |  0.0543538   |
| APR MDC Description                 | -0.138605   | -0.0482947   |  0.234025    | -0.0471249   |
| APR Severity of Illness Code        |  3.03986    |  0.392004    | -2.52946     | -0.902406    |
| APR Severity of Illness Description | -0.329607   | -0.161078    |  0.309168    |  0.181517    |
| APR Medical Surgical Description    | -0.184372   | -0.136837    |  0.265765    |  0.0554435   |
| Payment Typology 1                  |  0.111327   |  0.0374398   | -0.129166    | -0.0196013   |
| Payment Typology 2                  | -0.126269   |  0.0230675   |  0.0952741   |  0.00792733  |
| Payment Typology 3                  | -0.100608   |  0.0252739   |  0.0448402   |  0.0304942   |
| Birth Weight                        |  0.00516039 |  0.210522    | -0.192013    | -0.0236697   |
| Emergency Department Indicator      |  0.215975   | -0.00920575  | -0.174154    | -0.0326155   |
| Total Charges                       |  0.0734644  |  0.191091    | -0.118996    | -0.145559    |
| Total Costs                         |  0.214867   | -0.0152467   | -0.118849    | -0.0807709   |


## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



## SHAP Importance
![SHAP Importance](shap_importance.png)

## SHAP Dependence plots

### Dependence Extreme (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Extreme.png)
### Dependence Major (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Major.png)
### Dependence Minor (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Minor.png)
### Dependence Moderate (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Moderate.png)

## SHAP Decision plots

### Worst decisions for selected sample 1 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_0_worst_decisions.png)
### Worst decisions for selected sample 2 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_1_worst_decisions.png)
### Worst decisions for selected sample 3 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_2_worst_decisions.png)
### Worst decisions for selected sample 4 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_3_worst_decisions.png)
### Best decisions for selected sample 1 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_0_best_decisions.png)
### Best decisions for selected sample 2 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_1_best_decisions.png)
### Best decisions for selected sample 3 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_2_best_decisions.png)
### Best decisions for selected sample 4 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_3_best_decisions.png)

[<< Go back](../README.md)
